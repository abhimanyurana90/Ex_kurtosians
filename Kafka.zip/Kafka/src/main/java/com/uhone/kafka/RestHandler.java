package com.uhone.kafka;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class RestHandler {
	
	private static final Logger log = LogManager.getLogger(RestHandler.class);
	@RequestMapping(value = "/uhokafka/", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public String  updateDetails(@RequestBody String updates) throws IOException, TimeoutException  {
		
		log.info("Received the Stream...." +  updates.trim());		
		
		new UHOKafkaProducer().publishData(updates);
		//new UHOKafkaConsumer().consumerCall();
		
/*		StreamProducerConfig sconfig = new StreamProducerConfig();
			sconfig.ConfigPrducer(updates);
		
			StreamConsumerConfig scConfig = new StreamConsumerConfig();
		       scConfig.consumerCall();
*/	
		return "success";
		}

}
