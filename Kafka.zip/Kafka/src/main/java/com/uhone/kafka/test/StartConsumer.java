package com.uhone.kafka.test;

import com.uhone.kafka.UHOKafkaConsumer;


public class StartConsumer {
	
	public static void main(String args[]) {
		new UHOKafkaConsumer().consumerCall("mf");
	}

}
