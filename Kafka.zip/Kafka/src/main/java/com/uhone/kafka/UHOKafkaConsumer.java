package com.uhone.kafka;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.SslConfigs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Properties;

/*import org.json.JSONObject;*/
import org.json.simple.parser.*;
import org.json.simple.JSONObject;
/*import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONException;*/



public class UHOKafkaConsumer {
	
	public void consumerCall(String consumerGroup){
		 Properties props = new Properties();
	     props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "kaas-test-ctc-a.optum.com:443");
	     //configure the following three settings for SSL Encryption
	     props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL"); 
	     props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "C://Work/UHOne/Spring WS/Kafka/src/main/resources/kaas.client.truststore.jks");
	     props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,  "aQP8e2Ejm1s8NYjp");		    
		 	// configure the following three settings for SSL Authentication
		 props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "C://Work/UHOne/Spring WS/Kafka/src/main/resources/uhone-tst.keystore.jks");
		 props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "bzhwI0sa1Ebv4zKG");
		 props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "bzhwI0sa1Ebv4zKG");
		 props.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroup);
	     props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
	     props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
	     props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
	     KafkaConsumer<byte[], byte[]> consumer = new KafkaConsumer<>(props);
	     TestConsumerRebalanceListener rebalanceListener = new TestConsumerRebalanceListener();
	     consumer.subscribe(Collections.singletonList("kaas.uhone.test-topic"), rebalanceListener);
	     String data = "";  
	       	while (true) {	       		
	       		
	           ConsumerRecords<byte[], byte[]> records = consumer.poll(1000);
	           for (ConsumerRecord<byte[], byte[]> record : records) {
	        	   //data = record.value();
	        	   
	        	   System.out.println("...record..."+record.toString());
	        	   System.out.printf("Kafka Consumer....  Message Received.... %s, from topic =%s, on partition =%s, at offset = %d, key = %s, \n", record.value(), record.topic(), record.partition(), record.offset(), record.key());
	        	   
	        	   data =""+record.value();
	        	  writeData(data,consumerGroup);
	        	 
	            
	           }	          
	           consumer.commitSync();
	        //   return data;
	       }	       
	   }

	/*private void updateData(String data, String consumerGroup) {
		  JSONObject output;
	        try {
	        	 System.out.println("in update data...");
	           output = new JSONObject(data.toString());
	            JSONArray docs = output.getJSONArray("member");

	          //  File file=new File("/tmp2/fromJSON.csv");
	            String csv = CDL.toString(docs);
	           System.out.println("CSV..."+csv);
	           // FileUtils.writeStringToFile(file, csv);
	        } catch (JSONException e) {
	            e.printStackTrace();
	        }  
	}
*/	
	private void writeData(String data, String consumerGroup)  {
		System.out.println ("in write data..."+data);
		String filePath = "c:/temp/kafkatest/"+consumerGroup+"/MemberData.csv";
		System.out.println (filePath);
		try {
		JSONParser jsonParser = new JSONParser();		
		JSONObject jsonObject = (JSONObject) jsonParser.parse(data);
		System.out.println ("json object...."+jsonObject.toString());
		String memberId = (String) jsonObject.get("id");
		String memberObject = memberId;
		memberObject = memberObject + "," + (String) jsonObject.get("name");
		memberObject = memberObject + "," + (String) jsonObject.get("address");
		memberObject = memberObject + "," + (String) jsonObject.get("city");
		memberObject = memberObject + "," + (String) jsonObject.get("zip");
		memberObject = memberObject + "," + (String) jsonObject.get("state");
		memberObject = memberObject + "," + (String) jsonObject.get("phone");
		memberObject = memberObject + "," + (String) jsonObject.get("email");
		memberObject = memberObject + "," + (String) jsonObject.get("preference");
		
		System.out.println("member object..."+memberObject);
		File fileToUpdate = new File(filePath);
		String content = "";
		BufferedReader reader = null;
		FileWriter writer = null;
		try {			
	            reader = new BufferedReader(new FileReader(fileToUpdate));
	            String line = reader.readLine();
	            
	            while (line != null) 
	            {
	            	
	            	if (!line.startsWith(memberId)) 
	            		//line = memberObject;
	            		//content = content + memberObject + System.lineSeparator();
	            	//else
	            		content = content + line + System.lineSeparator();
	            	System.out.println("line..."+line.startsWith(memberId) + "..."+content);
	                line = reader.readLine();
	            }
	            content = content + memberObject +  System.lineSeparator();
	            writer = new FileWriter(fileToUpdate);	            
	            writer.write(content);
	            System.out.println("file contents..."+content);
	            reader.close();		                
                writer.close();
	        } catch (IOException e)   {
		            e.printStackTrace();
		        }
		} catch (Exception e) {
 		   System.out.println("EXCCCC..."+e.toString());
 		   e.printStackTrace();
 		   }
		}
		
			

	private static class  TestConsumerRebalanceListener implements ConsumerRebalanceListener {
	       @Override
	       public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
	           System.out.println("Called onPartitionsRevoked with partitions:" + partitions);
	       }

	       @Override
	       public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
	           System.out.println("Called onPartitionsAssigned with partitions:" + partitions);
	       }
	   }
}
