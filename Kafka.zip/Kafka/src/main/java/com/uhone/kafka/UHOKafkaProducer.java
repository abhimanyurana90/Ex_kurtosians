package com.uhone.kafka;

import java.io.File;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class UHOKafkaProducer {

	private static final Logger log = LogManager.getLogger(UHOKafkaProducer.class);
	public void publishData(String pubData) {
		Properties prop = new Properties();
		prop.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "kaas-test-ctc-a.optum.com:443");
		
		//configure the following three settings for SSL Encryption
		prop.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
		
	//	File file = new File("/resources/kaas.client.truststore.jks");
	//	String sample = file.toString();
		prop.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "C://Work/UHOne/Spring WS/Kafka/src/main/resources/kaas.client.truststore.jks");		
	    prop.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,  "aQP8e2Ejm1s8NYjp");
	    
	    // configure the following three settings for SSL Authentication
	    prop.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "C://Work/UHOne/Spring WS/Kafka/src/main/resources/uhone-tst.keystore.jks");
	    prop.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "bzhwI0sa1Ebv4zKG");
	    prop.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "bzhwI0sa1Ebv4zKG");
	    prop.put(ProducerConfig.CLIENT_ID_CONFIG, "uhone");
		prop.put(ProducerConfig.ACKS_CONFIG, "all");
		prop.put(ProducerConfig.RETRIES_CONFIG, 0);
		prop.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringSerializer");
		prop.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
		//prop.put(ProducerConfig.PARTITIONER_CLASS_CONFIG,"1");
		log.info("The Producer Constructed metod is " + prop.toString());
		
		long time = System.currentTimeMillis();
		String keyValue = String.valueOf(time);	
		//Producer<String, String> producer = new Producer<String, String>(prop);
		KafkaProducer<String, String> producer = new KafkaProducer<String, String>(prop);
		ProducerRecord<String, String> data = new ProducerRecord<String, String>("kaas.uhone.test-topic", pubData);
		
		try {
				producer.send(data).get();
				System.out.println("Kafka Producer....Record sent with key"  + data.toString()   );
			
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//log.info(" Kafka Producer.....Producer data " +data.toString());
		producer.close();
	}
	
}
