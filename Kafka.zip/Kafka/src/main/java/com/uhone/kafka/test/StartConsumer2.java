package com.uhone.kafka.test;

import com.uhone.kafka.UHOKafkaConsumer;

public class StartConsumer2 {
	
	public static void main(String args[]) {
		new UHOKafkaConsumer().consumerCall("estore");
	}

}
